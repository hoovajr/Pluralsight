from setuptools import setup

setup(
    name='pydownloader',
    version='1.0',
    description='using pydownloader to test site-package module insertion',
    author="Rob Hoover",
    author_email='hoovajr1@yahoo.com',
    py_modules=['pydownloader'],
    )